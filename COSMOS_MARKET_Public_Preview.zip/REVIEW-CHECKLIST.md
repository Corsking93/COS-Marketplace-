# COSMOS MARKET public landing page preview

Status: local draft only. Not deployed.

## Preview
Open `index.html` in a browser. It is a standalone static page with no external scripts, tracking pixels, remote assets, checkout, or live affiliate links.

## Before public release
- [ ] Replace the draft contact section with a monitored business email/contact method.
- [ ] Add a real public URL and accurate publisher/site details to the Awin application.
- [ ] Review the page against Awin's current publisher requirements and any requested changes.
- [ ] Publish a privacy notice appropriate to any data actually collected. Do not claim data practices that are not implemented.
- [ ] Only add merchant logos, products, prices, claims, and links when authorized and verified.
- [ ] Keep demo cards labelled as demos until real offers are approved and verified.
- [ ] Ensure affiliate disclosures are visible near affiliate links and meet applicable Canadian disclosure requirements.
- [ ] Test mobile layout, keyboard navigation, contrast, and links.
- [ ] Keep COSMOS MARKET admin service bound to 127.0.0.1. Do not expose port 8765 or .admin_token publicly.

## Current limitations
- No domain, hosting, contact email, live merchant relationships, Awin credentials, affiliate URLs, payment handling, or rewards payouts are configured by this preview.
- This page does not submit an Awin application or guarantee approval.
- Publish/deploy only after the owner reviews and approves the finished details.

COSMOS MARKET - PUBLIC LANDING PAGE PREVIEW
============================================

This is a static, local draft prepared for review. It has NOT been deployed.

Preview:
- Open index.html in a browser.
- No server is required to view this static page.
- It contains no external JavaScript, tracking pixels, checkout, or live affiliate links.

Before publishing:
1. Add a monitored business contact email and accurate owner/project information.
2. Choose a hosting provider and public domain or other public URL.
3. Ensure the Awin application details match the real public promotional property.
4. Review Awin's current rules and any direct requests from its publisher approval team.
5. Add a privacy notice that reflects actual data collection and processing.
6. Only publish real product claims, prices, merchant names, and links when verified and authorized.
7. Keep demo content labelled as demo until replaced with approved live listings.
8. Keep the COSMOS MARKET admin API bound to 127.0.0.1. Never publish .admin_token, .awin_token, the database, logs, or the admin service.
9. Test on mobile and desktop and check accessibility and disclosures.

Current state:
- Local preview only.
- No domain or hosting selected.
- No Awin credentials configured.
- No live merchant integrations or affiliate links.
- No checkout, payment processing, or payouts.
- The draft does not guarantee Awin approval.

This package intentionally includes only public-preview files. Do not add secret files to it.
